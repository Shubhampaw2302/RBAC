﻿using MimeKit;

namespace AuthSystem.Models.CoreModels
{
    public class Message
    {
        public List<MailboxAddress> To { get; set; }
        public string Subject { get; set; }
        public string Content { get; set; }
        public string? HtmlMessage { get; set; }
        public Message(IEnumerable<string> to, string subject, string content, string? htmlMessage = null)
        {
            To = [.. to.Select(x => new MailboxAddress("email", x))];
            Subject = subject;
            Content = content;
            HtmlMessage = htmlMessage;
        }
    }
}
