﻿using AuthSystem.Models.CoreModels;

namespace AuthSystem.Services
{
    public interface IEmailService
    {
        void SendEmail(Message message);
    }
}
