﻿namespace AuthSystem.Constants
{
    public enum Roles
    {
        Admin,
        User
    }
}
