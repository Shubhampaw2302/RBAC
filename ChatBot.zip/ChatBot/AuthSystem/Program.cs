using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using AuthSystem.Data;
using AuthSystem.Areas.Identity.Data;
using Microsoft.AspNetCore.Authentication.Google;
using AuthSystem.Models.CoreModels;
using System.Configuration;
using AuthSystem.Services;
var builder = WebApplication.CreateBuilder(args);
var connectionString = builder.Configuration.GetConnectionString("ChatBotContextConnection") ?? throw new InvalidOperationException("Connection string 'ChatBotContextConnection' not found.");

builder.Services.AddDbContext<ChatBotContext>(options => options.UseSqlServer(connectionString));

//builder.Services.AddDefaultIdentity<User>(options => options.SignIn.RequireConfirmedAccount = true).AddEntityFrameworkStores<ChatBotContext>();

builder.Services.AddIdentity<User, IdentityRole>(options => options.SignIn.RequireConfirmedAccount = false)
                .AddEntityFrameworkStores<ChatBotContext>()
                .AddDefaultUI()
                .AddDefaultTokenProviders();


// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddRazorPages();

builder.Services.Configure<IdentityOptions>(options =>
{
    options.Password.RequireUppercase = false;      // Upper case characters made optional. Check the definition of RequireUppercase for other details.
});

builder.Services.AddAuthentication().AddGoogle(GoogleDefaults.AuthenticationScheme, options =>
                                    {
                                        options.ClientId = builder.Configuration.GetSection("GoogleKeys:ClientID").Value!;
                                        options.ClientSecret = builder.Configuration.GetSection("GoogleKeys:ClientSecret").Value!;
                                    })
                                    .AddFacebook(options =>
                                    {
                                        options.ClientId = builder.Configuration.GetSection("FaceBookKeys:ClientID").Value!;
                                        options.ClientSecret = builder.Configuration.GetSection("FaceBookKeys:ClientSecret").Value!;
                                    });

var emailConfig = builder.Configuration.GetSection("EmailConfiguration").Get<EmailConfiguration>();
builder.Services.AddSingleton(emailConfig);

builder.Services.AddScoped<IEmailService, EmailService>();


var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.MapRazorPages();

//using (var scope = app.Services.CreateScope())
//{
//    await RoleSeeder.SeedRolesAndAdminAsync(scope.ServiceProvider);
//}

app.Run();
